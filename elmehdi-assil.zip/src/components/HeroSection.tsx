import React, { useState } from 'react';
import { ArrowRight, MessageCircle, Send, Calendar, Check, ShieldCheck } from 'lucide-react';

interface HeroSectionProps {
  whatsappNumber: string;
  onOpenContactModal: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ whatsappNumber, onOpenContactModal }) => {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const whatsappUrl = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
    'Bonjour Brandini, je souhaite discuter d\'un projet publicitaire.'
  )}`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you'd send data here.
    // For now, we'll show success state or open the existing modal.
    onOpenContactModal();
  };

  return (
    <section id="hero" className="relative pt-2 pb-12 md:pt-4 md:pb-20 overflow-hidden bg-white text-slate-900 border-b border-slate-200 min-h-[85vh] flex items-center">
      
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#307654]/5 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Messaging */}
          <div className="flex flex-col items-start space-y-6">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-50 text-[#307654] border border-emerald-200 text-[10px] sm:text-xs font-black uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-[#307654] animate-pulse"></span>
              <span>Agence de Marketing Digital</span>
            </div>

            {/* Main Title */}
            <h1 className="font-['Inter',sans-serif] font-black text-4xl sm:text-6xl text-slate-900 tracking-tight leading-[1.05] uppercase">
              DES CAMPAGNES <br />
              PUBLICITAIRES QUI{' '}
              <span className="text-[#307654] underline decoration-[#307654]/20 underline-offset-8">
                RAPPORTENT
              </span>
            </h1>
            
            {/* Subtitle */}
            <p className="max-w-xl text-lg sm:text-xl text-slate-600 font-medium leading-relaxed">
              Agence de marketing digital spécialisée pour e-commerce. Nous gérons vos budgets Ads avec un seul objectif : <span className="text-[#307654] font-bold">générer un vrai retour sur investissement</span>.
            </p>

            {/* Trust Indicators */}
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <div className="flex items-center gap-2 text-slate-500 text-sm font-bold">
                <Check className="w-4 h-4 text-[#307654]" />
                <span>Meta Ads</span>
              </div>
              <div className="flex items-center gap-2 text-slate-500 text-sm font-bold">
                <Check className="w-4 h-4 text-[#307654]" />
                <span>Google Ads</span>
              </div>
              <div className="flex items-center gap-2 text-slate-500 text-sm font-bold">
                <Check className="w-4 h-4 text-[#307654]" />
                <span>TikTok Ads</span>
              </div>
            </div>

            {/* Secondary CTA */}
            <div className="pt-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 text-slate-900 hover:text-[#307654] font-black text-sm uppercase tracking-wider transition-all"
              >
                <MessageCircle className="w-5 h-5 fill-slate-900 text-white" />
                <span>Ou Discuter via WhatsApp</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Right Column: Contact Form */}
          <div className="relative">
            {/* Decorative background element for the form */}
            <div className="absolute -inset-4 bg-slate-50/50 rounded-[40px] blur-xl -z-10"></div>
            
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xl shadow-slate-200/50 relative">
              <div className="mb-6">
                <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Demander un Devis</h2>
                <p className="text-slate-500 text-sm font-medium mt-1">Réponse garantie sous quelques minutes.</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5 ml-1">
                      Nom Complet
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Youssef Benali"
                      className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-200 text-slate-900 text-sm font-medium focus:outline-none focus:border-[#307654] focus:ring-4 focus:ring-[#307654]/10 transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5 ml-1">
                      Email Pro
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="votre@entreprise.com"
                      className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-200 text-slate-900 text-sm font-medium focus:outline-none focus:border-[#307654] focus:ring-4 focus:ring-[#307654]/10 transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5 ml-1">
                      Téléphone / WhatsApp
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="06 27 72 20 61"
                      className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-200 text-slate-900 text-sm font-medium focus:outline-none focus:border-[#307654] focus:ring-4 focus:ring-[#307654]/10 transition-all"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 px-6 mt-4 rounded-2xl bg-[#307654] hover:bg-[#245d42] text-white font-black text-base flex items-center justify-center gap-3 shadow-xl shadow-[#307654]/20 transition-all active:scale-95 cursor-pointer"
                >
                  <Send className="w-5 h-5 fill-white" />
                  <span>Obtenir Mon Devis Gratuit</span>
                </button>

                <div className="flex items-center justify-center gap-4 pt-4 border-t border-slate-100">
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Confidentialité 100%</span>
                  </div>
                  <div className="w-1 h-1 rounded-full bg-slate-300"></div>
                  <a
                    href="https://calendly.com/forzama7/30min"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 text-[10px] font-bold text-[#307654] uppercase tracking-wider hover:underline"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Ou RDV Stratégique</span>
                  </a>
                </div>
              </form>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
