import React from 'react';
import { TrendingUp, Target, Users, BarChart3 } from 'lucide-react';

export const ResultsSection: React.FC = () => {
  const stats = [
    {
      label: 'Budget Pub Géré',
      value: '2.5M+',
      suffix: 'DH',
      icon: <TrendingUp className="w-5 h-5" />,
    },
    {
      label: 'Campagnes Lancées',
      value: '450+',
      suffix: '',
      icon: <Target className="w-5 h-5" />,
    },
    {
      label: 'ROAS Moyen',
      value: '4.2x',
      suffix: '',
      icon: <BarChart3 className="w-5 h-5" />,
    },
    {
      label: 'Clients Satisfaits',
      value: '120+',
      suffix: '',
      icon: <Users className="w-5 h-5" />,
    },
  ];

  return (
    <section id="resultats" className="py-12 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
          {stats.map((stat, index) => (
            <div key={index} className="flex flex-col items-center text-center space-y-2">
              <div className="text-[#307654] mb-1 opacity-80">
                {stat.icon}
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 tracking-tighter">
                  {stat.value}
                </span>
                {stat.suffix && (
                  <span className="text-sm font-bold text-slate-400 uppercase">
                    {stat.suffix}
                  </span>
                )}
              </div>
              <p className="text-[10px] sm:text-xs font-black text-slate-500 uppercase tracking-widest">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
