import React from 'react';
import { Star, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../data/mockData';

interface ReviewsSectionProps {
  whatsappNumber: string;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = () => {
  return (
    <section id="avis" className="py-24 bg-white relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-emerald-50 rounded-full blur-3xl opacity-50"></div>
        <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-slate-50 rounded-full blur-3xl opacity-50"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#307654]/10 text-[#307654] border border-[#307654]/20 text-[10px] font-black uppercase tracking-widest">
            <span>Avis & Retours Clients</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black font-['Inter'] text-slate-900 uppercase tracking-tight leading-[1.1]">
            Ce Que Nos Clients <span className="text-[#307654]">Disent De Nous</span>
          </h2>
          <p className="text-slate-600 text-lg font-medium">
            Découvrez les retours d'expérience des entreprises qui ont fait confiance à Brandini Agency pour leur croissance digitale.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {TESTIMONIALS.map((testimonial) => (
            <div 
              key={testimonial.id}
              className="group bg-slate-50 border border-slate-200 p-8 rounded-3xl hover:bg-white hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-300 relative"
            >
              <Quote className="absolute top-6 right-8 w-10 h-10 text-slate-200 group-hover:text-emerald-100 transition-colors" />
              
              <div className="space-y-6 relative z-10">
                {/* Rating */}
                <div className="flex gap-0.5">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#307654] text-[#307654]" />
                  ))}
                </div>

                {/* Text */}
                <p className="text-slate-700 text-sm leading-relaxed font-medium italic">
                  {testimonial.text}
                </p>

                {/* Author Info */}
                <div className="flex items-center gap-4 pt-4 border-t border-slate-200">
                  <div className={`w-12 h-12 rounded-xl ${testimonial.avatarColor} flex items-center justify-center text-white font-black text-sm shadow-sm`}>
                    {testimonial.initials}
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-slate-900 font-['Inter'] uppercase tracking-tight">
                      {testimonial.name}
                    </h4>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-0.5">
                      {testimonial.role} • <span className="text-[#307654]">{testimonial.business}</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Trust Badge */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-6 px-8 py-4 rounded-2xl bg-slate-900 text-white shadow-xl">
            <div className="flex -space-x-2">
              {TESTIMONIALS.slice(0, 4).map((t) => (
                <div key={t.id} className={`w-8 h-8 rounded-full border-2 border-slate-900 ${t.avatarColor} flex items-center justify-center text-[10px] font-black`}>
                  {t.initials}
                </div>
              ))}
            </div>
            <div className="text-left">
              <p className="text-xs font-black uppercase tracking-widest">Score de satisfaction : 4.9/5</p>
              <p className="text-[10px] text-slate-400 font-medium">+50 entreprises accompagnées au Maroc & International</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
