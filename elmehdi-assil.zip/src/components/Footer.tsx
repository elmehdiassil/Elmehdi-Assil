import React from 'react';
import { MessageCircle, Mail, Phone, Instagram } from 'lucide-react';

interface FooterProps {
  whatsappNumber: string;
}

export const Footer: React.FC<FooterProps> = ({ whatsappNumber }) => {
  const formattedWhatsappUrl = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
    'Bonjour Brandini Agency, je vous contacte depuis le site.'
  )}`;

  return (
    <footer className="bg-slate-900 text-white border-t border-slate-800 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
          
          {/* Brand Bio (5 Cols) */}
          <div className="md:col-span-5 space-y-4">
            <a href="#" className="flex items-center">
              <span className="font-['Inter'] font-black text-2xl tracking-tighter text-white uppercase">
                BRANDINI <span className="text-[#307654]">AGENCY</span>
              </span>
            </a>

            <p className="text-slate-400 text-sm leading-relaxed max-w-sm">
              Agence de marketing digital spécialisée Meta, Google & TikTok Ads. Experts de la gestion de campagnes d'acquisition payante et stratégie digitale pour E-Commerce, boutiques et services.
            </p>

            {/* Social Icons */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://instagram.com/brandiniagency"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 hover:text-pink-400 hover:border-pink-500/50 transition-colors"
                title="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={formattedWhatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 hover:text-emerald-400 hover:border-emerald-500/50 transition-colors"
                title="WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Direct Links Column (3 Cols) */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="font-extrabold text-white text-xs font-['Inter'] uppercase tracking-wider">
              Sections Du Site
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400 font-medium">
              <li>
                <a href="#hero" className="hover:text-[#307654] transition-colors">
                  1. Accueil
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#307654] transition-colors">
                  2. Services Spécialisés
                </a>
              </li>
              <li>
                <a href="#clients" className="hover:text-[#307654] transition-colors">
                  3. Nos Clients
                </a>
              </li>
              <li>
                <a href="#avis" className="hover:text-[#307654] transition-colors">
                  4. Avis Clients
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info Column (4 Cols) */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="font-extrabold text-white text-xs font-['Inter'] uppercase tracking-wider">
              Coordonnées Directes
            </h4>
            <ul className="space-y-3 text-xs text-slate-300 font-medium">
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#307654] shrink-0" />
                <a href="tel:0627722061" className="hover:text-emerald-400 font-mono font-bold transition-colors">
                  06 27 72 20 61
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 text-[#307654] shrink-0" />
                <a href={formattedWhatsappUrl} target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors">
                  WhatsApp Direct (06 27 72 20 61)
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#307654] shrink-0" />
                <a href="mailto:forzama7@gmail.com" className="hover:text-emerald-400 font-mono transition-colors break-all">
                  forzama7@gmail.com
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Rights */}
        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-medium">
          <p>© {new Date().getFullYear()} Brandini Agency - Tous droits réservés.</p>
          <p className="text-slate-400">Maroc & International</p>
        </div>

      </div>
    </footer>
  );
};
