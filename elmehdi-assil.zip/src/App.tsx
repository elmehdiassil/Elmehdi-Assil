import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ClientsSection } from './components/ClientsSection';
import { PricingSection } from './components/PricingSection';
import { ReviewsSection } from './components/ReviewsSection';
import { Footer } from './components/Footer';
import { WhatsappFloatingWidget } from './components/WhatsappFloatingWidget';
import { WhatsappSettingsModal } from './components/WhatsappSettingsModal';
import { ContactModal } from './components/ContactModal';

export function App() {
  const [whatsappNumber, setWhatsappNumber] = useState<string>('0627722061');
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState<boolean>(false);

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-['Inter',sans-serif] selection:bg-[#307654] selection:text-white">
      {/* Top Header Navigation */}
      <Navbar
        whatsappNumber={whatsappNumber}
        onOpenWhatsappSettings={() => setIsSettingsOpen(true)}
        onOpenContactModal={() => setIsContactModalOpen(true)}
      />

      {/* Main Single Page Condensed Continuous Scroll Content */}
      <main className="space-y-0">
        
        {/* 1. Hero */}
        <HeroSection
          whatsappNumber={whatsappNumber}
          onOpenContactModal={() => setIsContactModalOpen(true)}
        />

        {/* 3. Services (Pricing) */}
        <PricingSection whatsappNumber={whatsappNumber} />

        {/* 3. Mes Clients (Témoignages / Mes Clients) */}
        <ClientsSection whatsappNumber={whatsappNumber} />

        {/* 4. Avis Clients */}
        <ReviewsSection whatsappNumber={whatsappNumber} />
      </main>

      {/* Footer */}
      <Footer whatsappNumber={whatsappNumber} />

      {/* Floating WhatsApp Widget */}
      <WhatsappFloatingWidget
        whatsappNumber={whatsappNumber}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* WhatsApp Number Settings Drawer */}
      {isSettingsOpen && (
        <WhatsappSettingsModal
          currentNumber={whatsappNumber}
          onSave={(newNum) => setWhatsappNumber(newNum)}
          onClose={() => setIsSettingsOpen(false)}
        />
      )}

      {/* 3-Field Contact Modal Popup */}
      <ContactModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
        whatsappNumber={whatsappNumber}
      />
    </div>
  );
}

export default App;
